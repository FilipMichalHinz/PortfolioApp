namespace App.Tests.Models
{
    public class AssetResponse
    {
        public int Id { get; set; }
        public int PortfolioId { get; set; }
        public string Ticker { get; set; }
        public string Name { get; set; }
    }
}
