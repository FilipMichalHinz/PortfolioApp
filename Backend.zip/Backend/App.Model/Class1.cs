﻿namespace App.Model;

public class Class1
{

}
