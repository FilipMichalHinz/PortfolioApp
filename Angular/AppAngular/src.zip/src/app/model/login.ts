export interface Login {
    userId: number;
    username: string;
    authHeader: string;
  }
  