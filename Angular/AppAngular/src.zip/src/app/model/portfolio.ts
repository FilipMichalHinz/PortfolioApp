export interface Portfolio {
    id: number;
    name: string;
    createdAt: Date;
}
